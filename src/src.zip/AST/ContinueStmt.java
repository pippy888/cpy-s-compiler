package AST;

public class ContinueStmt extends Stmt{
}
