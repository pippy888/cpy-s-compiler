package AST;

public class BreakStmt extends Stmt{
}
