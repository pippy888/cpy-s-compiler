package AST;

public class IfStmt extends Stmt{
    private CondStmt condStmt;

    private Stmt thenStmt;

    private Stmt elseStmt;

    public IfStmt(CondStmt condStmt, Stmt thenStmt, Stmt elseStmt) {
        this.condStmt = condStmt;
        this.thenStmt = thenStmt;
        this.elseStmt = elseStmt;
    }
}
