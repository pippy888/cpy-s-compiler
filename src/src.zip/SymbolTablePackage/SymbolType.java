package SymbolTablePackage;

public enum SymbolType {
    var,
    function,
    blockSymbolTable,
}
