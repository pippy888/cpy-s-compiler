package Ir.IRInstr;

public class Instr{

    public String genIr() {
        return null;
    }
}
